// environment.ts
export const environment = {
    production: false,
    baseUrl: 'http://localhost:8080', // Replace with your backend API URL
    stripePublishableKey: "pk_test_51OI64cSAdwes2nOtw6JB4l5bqldz1R5T08hcZjTBlDsZo3XZ8zpDV7ncSDCgWCsA0IQ7rRyECpdTXmuVLwq1BqxF00LFdPMRDr"

  };
  