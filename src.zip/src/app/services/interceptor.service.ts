import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NzMessageService } from 'ng-zorro-antd/message';
import { Observable, catchError, throwError } from 'rxjs';
import jwt_decode from 'jwt-decode';
@Injectable({
  providedIn: 'root'
})
export class InterceptorService implements HttpInterceptor {
  setToken(token: string) {
    localStorage.setItem('jwtToken', token);
  }

  getToken() {
    return localStorage.getItem('jwtToken')
  }

  getCurrentUserData(): any {
    return jwt_decode(this.getToken()!);
  }

  constructor(private notify: NzMessageService) { }
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    var authReq = req
    if (localStorage.getItem('jwtToken')) {
      authReq = req.clone({
        headers: req.headers.set('Authorization', `Bearer ${this.getToken()}`)
      });
    }
    return next.handle(authReq).pipe(
      catchError(errorData => {
        if (errorData.status === 401) {
          this.logOut()
        }
        return throwError(errorData)
      })
    )
  }

  logOut() {
    localStorage.clear()
    // window.location.reload()
    this.notify.info("Something went wrong! Login again!")
  }
  }

