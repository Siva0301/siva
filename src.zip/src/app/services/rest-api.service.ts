import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Apiresponse } from '../models/apiresponse';
import { Category } from '../models/category';
import { Product } from '../models/product';
import { Cart } from '../models/cart';
import { LoginRequest } from '../models/login-request';
import { Observable, catchError } from 'rxjs';
import { InterceptorService } from './interceptor.service';
import { Paymentinfo } from '../models/paymentinfo';
import { environment } from 'src/environment/environment';
@Injectable({
  providedIn: 'root'
})
export class RestApiService {

private baseUrl = 'http://localhost:8080';
private paymentUrl=environment.baseUrl +'/payment/createpayment'

  constructor(   private httpClient: HttpClient,
    private router: Router,private tokenservice:InterceptorService
    ) { }

    public createpayment(Payment:Paymentinfo){
      return this.httpClient.post<Apiresponse>(
      this.paymentUrl,Payment
      );

    }

    public registerCategory(Category:Category){
    return this.httpClient.post<Apiresponse>(
        `${this.baseUrl}/category/save`,
        Category
      );
  }

  // addToCart(product: Product): void {
  //   this.cart.products.push(product);
  // }
 

  


  public registerCart(userId:number,productIds: number[]): Observable<Apiresponse> {
  

    if (userId !== null) {
      const params = new HttpParams()
        .set('userId', userId.toString())
        .set('productIds', productIds.join(','));

      return this.httpClient.post<Apiresponse>(`${this.baseUrl}/cart/save`, null, { params });
    } else {
      // Handle the case where the user is not authenticated
      // You might want to redirect to the login page or show an error message
      console.error('User is not authenticated');
      return new Observable(); // Return an empty observable or handle accordingly
    }
  }
  


  public viewCatagory() {
    return this.httpClient.get<Apiresponse>(
      `${this.baseUrl}/category/list`
    );
}
public viewCatagoryid(id:number) {
  return this.httpClient.get<Apiresponse>(
    `${this.baseUrl}/category/${id}`
  );
}
public viewproductbyCatagory(id:number) {
  return this.httpClient.get<Apiresponse>(
    `${this.baseUrl}/product/category/${id}`
  );
}

public viewproductid(id:number) {
  return this.httpClient.get<Apiresponse>(
    `${this.baseUrl}/product/${id}`
  );
}



public viewproduct(){
  return this.httpClient.get<Apiresponse>(`${this.baseUrl}/product/list`,)
}

public downloadproductImg(id: number) {
  return this.httpClient.get(`${this.baseUrl}/product/file/${id}`,{ responseType: 'blob' });  
}
// public downloadallproductImg() {
//   return this.httpClient.get(`${this.baseUrl}/product/file`,{ responseType: 'blob' });  
// }

searchProducts(name: string): Observable<Product[]> {
  const params = new HttpParams().set('name', name.toString());

  return this.httpClient.get<Product[]>(`${this.baseUrl}/product/search`, { params })
}
  //Authenticate APIS:
  public login(loginRequest: LoginRequest) {
    return this.httpClient.post<Apiresponse>(
      `${this.baseUrl}/user/authenticate`,
      loginRequest
    );
  }
}
