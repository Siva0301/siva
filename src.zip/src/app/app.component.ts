import { Component, OnInit } from '@angular/core';
import { InterceptorService } from './services/interceptor.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit  {
  constructor(private interceptor: InterceptorService, private router: Router) { }
  isLoggedIn = false
  ngOnInit(): void {
    if (localStorage.getItem('jwtToken')) {
      this.isLoggedIn = true
    }
    else {
      this.router.navigateByUrl('/login')
    }
  }


}
