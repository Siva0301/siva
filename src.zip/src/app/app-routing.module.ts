import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LayoutComponent } from './components/layout/layout.component';
import { CategoryListComponent } from './components/category-list/category-list.component';
import { CategoryComponent } from './components/category/category.component';
import { ProductListComponent } from './components/product-list/product-list.component';
import { LoginComponent } from './components/login/login.component';
import { ProductComponent } from './components/product/product.component';
import { PaymentComponent } from './components/payment/payment.component';
// import { ViewProductsComponent } from './components/view-products/view-products.component';

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: '/welcome' },
  {path: 'layout', component: LayoutComponent} ,
  {path: 'View-Category', component: CategoryListComponent} ,
  {path: 'Create-Category', component: CategoryComponent} ,
  {path: 'product-view', component: ProductComponent} ,
  { path: 'login', component: LoginComponent },
  { path: 'payment', component: PaymentComponent },
  // {path: 'product-view', component: ViewProductsComponent} 

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
