export class Product {
    id:number;
  
    name:string;
    catagoryid:number;
    price:number;
    description:string;
  file:Blob;
  filename:string;
    constructor(id:number,name:string,catagoryid:number,price:number, description:string,file:Blob,
        filename:string){
        this.id = id;
        this.name = name;
        this.catagoryid = catagoryid;
        this.price=price;
        this.description=description;
        this.file=file;
        this.filename=filename
       

      
    }
}
