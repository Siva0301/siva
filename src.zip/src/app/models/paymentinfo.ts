export class Paymentinfo {
    Amount:number;
    Currency:string;
cardNumber: any;

    constructor( Amount:number,
        Currency:string)
{
this.Amount=Amount;
this.Currency=Currency
}
        
}
