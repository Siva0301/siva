import { Product } from "./product";

export class Cart {
 id:number;
  userid:number;
  
    productIds:number[];

    constructor(id:number,
      userid:number,productIds:number[]){
        this.id=id;
        this.userid=userid;
        this.productIds = productIds;
    }

    private products: Product[] = [];

    getItems(): Product[] {
      return this.products;
    }
  
    addItem(product: Product): void {
      this.products.push(product);
    }
  
    removeItem(product: Product): void {
      this.products = this.products.filter(item => item.id !== product.id);
    }
  
    clearCart(): void {
      this.products = [];
    }
  
    getTotalPrice(): number {
      return this.products.reduce((total, item) => total + item.price, 0);
    }
    
}

