import { Apiresponse } from './apiresponse';

describe('Apiresponse', () => {
  it('should create an instance', () => {
    expect(new Apiresponse()).toBeTruthy();
  });
});
