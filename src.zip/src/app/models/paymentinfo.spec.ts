import { Paymentinfo } from './paymentinfo';

describe('Paymentinfo', () => {
  it('should create an instance', () => {
    expect(new Paymentinfo()).toBeTruthy();
  });
});
