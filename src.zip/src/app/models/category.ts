export class Category {
    id:number;
    categoryname:string;
   
    constructor(id:number, categoryname:string){
        this.id = id;
        this.categoryname = categoryname;
      
    }
}

