import { Component, Input, OnInit, Output } from '@angular/core';
import { UntypedFormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { NzMessageService } from 'ng-zorro-antd/message';
import { Product } from 'src/app/models/product';
import { RestApiService } from 'src/app/services/rest-api.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
ser:any=[]
productImageUrls: { [key: number]: string } = {};

  @Input()
  categoryid : any



  products: Product[]=[];
  
  
  imageToShow:  any = null;
  showSpinner: boolean=true;
  ngOnInit(): void {
  // this.viewpro(this.id)

    this.getProductsByCategory(this.categoryid)
    
  }
  constructor(private fb: UntypedFormBuilder,private router:Router,private notification:NzMessageService,private restapi:RestApiService) {
    
  }





  viewpro(id:number) {
   
    this.restapi.viewproductid(id).subscribe(
      (data)=>
      {
      console.log("sucess",data)
      this.products=data.responseData
      this.ser=this.products
      // this.retreiveImage(data.responseData);
   
      },
      (Error)=>
      console.log("error",Error)
    )

  }
  // view() {
   
  //   this.restapi.viewproduct().subscribe(
  //     (data)=>
  //     {
  //     console.log("sucess",data)
  //     this.products=data.responseData
  //     this.ser=this.products
  //     // this.products.forEach((product) => {
  //     //   this.retreiveImage(product.id); // Assuming 'id' is the property representing the product ID
  //     // });
  //     // this.retreiveImage(this.categoryid);
   
  //     },
  //     (Error)=>
  //     console.log("error",Error)
  //   )

  // }
  getProductsByCategory(id: number): void {
    this.restapi.viewproductbyCatagory(id).subscribe(
      (data) => {
        this.products = data.responseData;
       this.ser=this.products
       this.products.forEach((product) => {
        this.restapi.downloadproductImg(product.id).subscribe(
          (image) => {
            this.productImageUrls[product.id] = URL.createObjectURL(image);
          },
          (error) => {
            console.error(`Error fetching image for product ${product.id}:`, error);
          }
        );
      });
        //  this.retreiveImage(this.categoryid)
        
  
      },
      (error) => {
        console.error('Error fetching products:', error);
      }
    );
  }


  
  
//   retreiveImage(id: number) {
//     this.restapi.downloadproductImg(id).subscribe(image => this.createImage(image)
//     );
//   }

//  createImage(image: Blob) {
//     if (image && image.size > 0) {
//       let reader = new FileReader();

//       reader.addEventListener("load", () => {
//         this.imageToShow = reader.result;
//         this.showSpinner = false;
//       }, false);

//       reader.readAsDataURL(image);
//     } else {
//       this.showSpinner = false;
//     }
//   }


}
