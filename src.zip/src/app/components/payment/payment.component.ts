import { AfterViewInit, Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { NzMessageService } from 'ng-zorro-antd/message';
import { Paymentinfo } from 'src/app/models/paymentinfo';
import { InterceptorService } from 'src/app/services/interceptor.service';
import { RestApiService } from 'src/app/services/rest-api.service';
import { environment } from 'src/environment/environment';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
  validateForm!: UntypedFormGroup;



stripe=Stripe(environment.stripePublishableKey)
payment!:Paymentinfo;
cardElement:any;
displayError:any= "";
  cardErrors: any;

  constructor(private fb: UntypedFormBuilder,private restApi: RestApiService,private notification:NzMessageService,private router: Router,private tokenservice:InterceptorService) {}

  ngOnInit(): void {
 
this.setupStripePaymentForm()
  }
 // Replace with your actual Stripe public key


 
  setupStripePaymentForm() {
    const elements = this.stripe.elements();
    this.cardElement = elements.create('card', { hidePostalCode: true });
    this.cardElement.mount('#card-element');

    this.cardElement.on('change', (event: any) => {
      const displayError = this.cardErrors.nativeElement;

      if (event.complete) {
        displayError.textContent = '';
      } else if (event.error) {
        displayError.textContent = event.error.message;
      }
    });
  }

  async submitPayment() {
    const { token, error } = await this.stripe.createToken(this.cardElement);

    if (error) {
      console.error(error);
    } else {
      // Send the token to your server for further processing
      console.log(token);
    }
  }
  // setupstripepaymentform() {
  // var elements=this.stripe.elements();
  // var cardElement=elements.create('card',{hidePostalcode:true})
  // this.cardElement.mount('#amount');
  // this.cardElement.on('change',(Event:any)=>{
  //   this.displayError=document.getElementById('card-errors');

  //   if(Event.complete){
  //     this.displayError.textcontent="";
      
  //   }
  //   else if
  //   (Event.error){
  //     this.displayError.textcontent=Event.error.message;

  //   }
  // })
  // }
    
  // onSubmit(): void {
  //   this.restApi.createpayment(this.payment)
  //     .subscribe(
  //       (response) => {
  //         console.log('Payment created successfully:', response);
  //         // Handle success, if needed
  //       },
  //       (error) => {
  //         console.error('Error creating payment:', error);
  //         // Handle error, if needed
  //       }
  //     );
  // }

}
