import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NzMessageService } from 'ng-zorro-antd/message';
import { LoginRequest } from 'src/app/models/login-request';
import { InterceptorService } from 'src/app/services/interceptor.service';
import { RestApiService } from 'src/app/services/rest-api.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  Userdata:any
  
  @Output()
  onLogin: EventEmitter<void> = new EventEmitter<void>();

  @Output()
  onRegister: EventEmitter<void> = new EventEmitter<void>();
  constructor(private fb: UntypedFormBuilder, private router: Router,
    private notification: NzMessageService, private restApiService: RestApiService, private tokenService: InterceptorService){}
    validateForm!: UntypedFormGroup;
  submitForm(): void {
    if (this.validateForm.valid) {
      console.log('submit', this.validateForm.value);
      this.login(this.validateForm.value)
    } else {
      Object.values(this.validateForm.controls).forEach(control => {
        if (control.invalid) {
          control.markAsDirty();
          control.updateValueAndValidity({ onlySelf: true });
        }
      });
    }
  }
  ngOnInit(): void {
    this.validateForm = this.fb.group({
      username: [null, [Validators.required]],
      password: [null, [Validators.required]]
    });
  }
  login(loginRequest: LoginRequest) {
    this.restApiService.login(loginRequest).subscribe(
      data => {
        this.tokenService.setToken(data.responseData);
        this.notification.success("Login Successful!")
        this.router.navigateByUrl("/View-Category")
        this.onLogin.emit()
      },
      error => {
        this.notification.error("Invalid Username/ Password");
        console.log("Error Occured", error);
        localStorage.removeItem('jwtToken')
      }
    )
  }
  handleRegister() {
    this.onRegister.emit();
  }

  show_button: Boolean = false;

  showPassword() {
    this.show_button = !this.show_button;
  }

  // logoutHandler() {
  //   localStorage.clear();
  //   window.location.replace('/login');
  //   this.notify.info("You have been Logged Out!")

  // }
}
