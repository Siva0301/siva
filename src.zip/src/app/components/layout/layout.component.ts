import { animate, style, transition, trigger } from '@angular/animations';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NzMessageService } from 'ng-zorro-antd/message';
import { InterceptorService } from 'src/app/services/interceptor.service';
import { RestApiService } from 'src/app/services/rest-api.service';

@Component({
  selector: 'app-layout',
  // animations: [
  //   trigger('fadeInOut', [
  //     transition(':enter', [
  //       style({ width: 0 }),
  //       animate('250ms', style({ width: 300 }))
  //     ]),
  //     transition(':leave', [
  //       animate('250ms', style({ width: 0 }))
  //     ])
  //   ])
  // ],
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.css']
})
export class LayoutComponent implements OnInit {
  userData: any;
  constructor(private router: Router, private tokenService: InterceptorService, private restApi: RestApiService,  private notify: NzMessageService){}
  ngOnInit(): void {
    this.userData = this.tokenService.getCurrentUserData();
  }
  isCollapsed = false;
  logoutHandler() {
    localStorage.clear();
    window.location.replace('/login');
    this.notify.info("You have been Logged Out!")

  }
  
}
