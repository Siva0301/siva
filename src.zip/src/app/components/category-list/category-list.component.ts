import { Component, Input, OnInit } from '@angular/core';
import { NzMessageService } from 'ng-zorro-antd/message';
import { Category } from 'src/app/models/category';
import { Product } from 'src/app/models/product';
import { RestApiService } from 'src/app/services/rest-api.service';

@Component({
  selector: 'app-category-list',
  templateUrl: './category-list.component.html',
  styleUrls: ['./category-list.component.css']
})
export class CategoryListComponent implements OnInit {
  options: any;

  updateID(event: { something: any; }) {
    this.model.managmentId = event.something
    }
  // category :Category[]=[];
model: any;

products:Product[]=[];
categories:Category[]=[];
selectedCategory: Category | null = null;
// @Input()
// categoryid:any

  // sdata!:bus;
  searchResults:any=[]

constructor(private restApi :RestApiService, private notifiication : NzMessageService,){}

// this.getcategory()
// this.delbus
// this.getcategoryproduct(this.categoryid);
ngOnInit(): void {
  // Assuming you have a categoryId, replace it with the actual categoryId

 this.getcategory()


}


      

getcategory()
{
  this.restApi.viewCatagory().subscribe(
    data=>{
      console.log("sucess",data)
      this.categories=data.responseData;
      this.searchResults=this.categories
      
    },
    error=>{
      console.log("ERROR", error)
    }
  )
}


}

// getcategoryproduct(catagoryid:number)
// {
//   this.restApi.viewproductbyCatagory(catagoryid).subscribe(
//     (data)=>{
  
//       this.product=data;
 
      
//     },
//     (error)=>{
//       console.log("ERROR", error)
//     }
//   )
// }

// selectChange(a:any)
// {
//   this.options = a
//   console.log(this.options)
// }

// delbus(id:number){
//   this.restApi.deletebus(id).subscribe(
//     data=>{
//       console.log("sucess",data)
//       this.notifiication.success("sucess")
//     },
//     error=>{
//       console.log("Error",error)
//       this.notifiication.error("error")
//     }
//   )

// }



// isVisible = false;
// isOkLoading = false;

// showModal(): void {
//   this.isVisible = true;
// }

// handleOk(): void {
//   this.isOkLoading = true;
//   setTimeout(() => {
//     this.isVisible = false;
//     this.isOkLoading = false;
//   }, 3000);
// }

// handleCancel(): void {
//   this.isVisible = false;
// }
// handleUpdatebus(data:bus) {
//   this.sdata= data;
//   this.isVisible = true
  
// }
