import { Component, Input } from '@angular/core';
import { UntypedFormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { NzMessageService } from 'ng-zorro-antd/message';
import { Product } from 'src/app/models/product';
import { InterceptorService } from 'src/app/services/interceptor.service';
import { RestApiService } from 'src/app/services/rest-api.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent {

  @Input()
  productid: any;
  imageToShow: any = null;

  showSpinner: boolean = true;
  products!:Product
  constructor(private fb: UntypedFormBuilder,private restApi: RestApiService,private notification:NzMessageService,private router: Router,private tokenservice:InterceptorService) {}
  userData: any
  ngOnInit() {
  this.view(this.productid)

  }

  searchResults: any = []
  searchQuery: string = '';
 searchdata( searchQuery:string) {
  console.log(searchQuery)
  this.products

  this.searchproducts(searchQuery)

}

view(productid:number) {
   
  this.restApi.viewproductid(productid).subscribe(
    (data)=>
    {
    console.log("sucess",data)
    this.products=data.responseData
 
    this.retreiveImage(this.products.id);
 
    },
    (Error)=>
    console.log("error",Error)
  )

}

    searchproducts(name:string) {

      this.restApi.searchProducts(name).subscribe(searchResults => {
        // this.products = searchResults;
        // this.retreiveImage(this.searchResults.id)
      });
   
    
  }
  
  retreiveImage(id: number) {
    this.restApi.downloadproductImg(id).subscribe(image => this.createImage(image)
    );
  }

 createImage(image: Blob) {
    if (image && image.size > 0) {
      let reader = new FileReader();

      reader.addEventListener("load", () => {
        this.imageToShow = reader.result;
        this.showSpinner = false;
      }, false);

      reader.readAsDataURL(image);
    } else {
      this.showSpinner = false;
    }
  }
}
