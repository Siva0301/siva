import { Component, Input } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NzMessageService } from 'ng-zorro-antd/message';
import { Cart } from 'src/app/models/cart';
import { Category } from 'src/app/models/category';
import { Product } from 'src/app/models/product';
import { InterceptorService } from 'src/app/services/interceptor.service';
import { RestApiService } from 'src/app/services/rest-api.service';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent {
  products:Product[]=[];
  totalAmount: number = 0;
  validateForm!: UntypedFormGroup;
carts:any[]=[]
selectedProductIds: number[] = [];
  imageToShow:  any = null;
  showSpinner: boolean=true;
cart!: Cart 
selectedProducts:any;
 quantity: number = 0;
name!: string 
productImageUrls: { [key: number]: string } = {};

productid!: number;
  // submitForm(): void {
  //   if (this.validateForm.valid) {
  //        console.log('submit', this.validateForm.value);
       
           
  //          this.createUser(this.validateForm.value);
        
  //      }
  //        else {
  //        Object.values(this.validateForm.controls).forEach(control => {
  //          if (control.invalid) {
  //            control.markAsDirty();
  //            control.updateValueAndValidity({ onlySelf: true });
  //          }
  //        });
  //      }
  //    }
    

  
  constructor(private fb: UntypedFormBuilder,private restApi: RestApiService,private notification:NzMessageService,private router: Router,private tokenservice:InterceptorService) {}
  userData: any
  ngOnInit(): void {
    
    this.userData = this.tokenservice.getCurrentUserData()
this.view();
}

calculateTotalAmount() {
  this.totalAmount = this.selectedProducts.reduce((total: number, product: { price: number; quantity: number; }) => total + product.price * product.quantity, 0);
}
viewId : any
visible = false
viewPage(id : any){
  this.viewId = id
  this.visible = true
}

  closeView()
  {
    this.visible = false
  }

  view(){
  this.restApi.viewproduct().subscribe(
    (data) => {
      this.products = data.responseData;
      // Retrieve product images
      this.products.forEach((product) => {
        this.restApi.downloadproductImg(product.id).subscribe(
          (image) => {
            this.productImageUrls[product.id] = URL.createObjectURL(image);
          },
          (error) => {
            console.error(`Error fetching image for product ${product.id}:`, error);
          }
        );
      });
    },
    (error) => {
      console.error('Error fetching product list:', error);
    }
  );

}
createUser(Category : Category)
  {
  
    this.restApi.registerCategory(Category).subscribe(
      data=>{
        console.log("Success", data)
        this.notification.success("User Created Successfully")
     
      },
      error=>{
        console.log("Failed", error)
        this.notification.error("Error Occurred")
      }
    )
  }

  

  switchValue = false;
  isCheckedButton = false;
  addItem(product: Product) {
    this.products.push(product);
    this.carts=this.products
    this.isCheckedButton = !this.isCheckedButton;
    this.notification.success("product Created Successfully")
    
  }

  removeProductSelection(productId: number) {
    const existingItemIndex = this.selectedProductIds.findIndex(id => id === productId);
  
    if (existingItemIndex !== -1) {
      this.selectedProductIds.splice(existingItemIndex, 1);
      this.quantity--;
    }
  }
  
  productlist: any = [];

  searchResults: any = []
 searchQuery: string = '';


 searchdata( searchQuery:string) {
  console.log(searchQuery)
  // this.products=[]

  this.searchproducts(searchQuery)

}
    searchproducts(searchQuery:string) {

      this.restApi.searchProducts(searchQuery).subscribe(searchResults => {
        this.products = searchResults;
      // this.loadProductList()
      });
   
    
  }

  toggleProductSelection(productIds: number): void {
    const index = this.selectedProductIds.indexOf(productIds);

    if (index === -1) {
      this.selectedProductIds.push(productIds);
      this.quantity++;
    } 
  }

  addSelectedProductsToCart(): void{
   



      this.restApi.registerCart(this.userData.userId, this.selectedProductIds).subscribe(
        (data) => {
          console.log('Success', data);
       
          this.notification.success('Cart created successfully');
          this.selectedProductIds = [];
          this.quantity=0;
          
        },
        (error) => {
          console.log('Failed', error);
          this.notification.error('Error occurred');
        }
      );
    
  }
}

  




  // Other component methods and logic

